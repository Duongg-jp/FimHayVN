import CategoryList from "../components/CategoryList";

export default function PhimBo() {
  return (
    <>
      <CategoryList TenTheLoai="Phim Bộ" />
    </>
  );
}
