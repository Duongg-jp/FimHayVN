import ThePhim from "./ThePhim";

export default function KhoiThePhim(params) {
  return (
    <>
      <div className="row g-3">
        <div className="col-6 col-sm-4 col-md-3 col-1-5">
          <ThePhim />
        </div>
      </div>
    </>
  );
}
