export default function NutXemTatCa() {
    return (
      <>
        <a className="btn-view-all" href="#">
          Xem tất cả &gt;
        </a>
      </>
    );
  }
  