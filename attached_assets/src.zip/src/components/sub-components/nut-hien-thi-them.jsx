export default function NutHienThiThem() {
  return (
    <>
      <button
        type="button"
        className="btn btn-show-more rounded-pill px-3 py-1 text-light "
      >
        Hiển thị thêm
      </button>
    </>
  );
}
