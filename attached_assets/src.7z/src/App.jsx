// src/App.jsx
import React from "react";
import AppRoutes from "./routes/AppRoutes";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

import "@/assets/css/Web.css";

function App() {
  return (
    <div className="App container-fluid background-web">
      <Header />
      <main>
        <AppRoutes />
      </main>
      <Footer />
    </div>
  );
}

export default App;
