import CategoryList from "../components/CategoryList";

export default function PhimLe() {
  return (
    <>
      <CategoryList TenTheLoai="Phim Lẻ" />
    </>
  );
}
