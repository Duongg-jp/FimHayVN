export default function TheLoaiPhim({ TenTheLoai }) {
  return (
    <>
      <h3 className="title-list">{TenTheLoai}</h3>
    </>
  );
}
